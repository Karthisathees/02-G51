
/*This stand-alone application test the connection to the db once setup in DB class
 *It performs an add-function of a Student to the database
 *To use this app, you should complete the addStudent method in DBManager class
 *
 *
 *@author George
**/
package uts.isd.controller;

import uts.isd.model.dao.DBManager;
import uts.isd.model.dao.DBConnector;
import uts.isd.model.User;
import java.sql.*;
import java.util.*;
import java.util.logging.*;

public class TestDB {
    private static Scanner in = new Scanner(System.in);
    
    public static void main(String[] args) {
        try {
            DBConnector connector = new DBConnector(); //Create a connection and initialize DB conn-field
            Connection conn = connector.openConnection(); //Get the protected connection instance from DB superclass to share for the application classes
            DBManager db = new DBManager(conn); //DBManger instance provide users with access to CRUD operations
            
          //  int key = (new Random()).nextInt(999999);
         //   String ID = "" + key; 
            System.out.print("User ID: ");
            String  ID = in.nextLine();
            System.out.print("User email: ");
            String email = in.nextLine();
            System.out.print("User firstName: ");
            String firstName = in.nextLine();
            System.out.print("User lastName: ");
            String lastName = in.nextLine();
            System.out.print("User password: ");
            String password = in.nextLine();
            System.out.print("User mobileNumber: ");
            String mobileNumber = in.nextLine();
            System.out.print("Student favorite color: ");
            String favcol = in.nextLine();
            
            User user = db.findUser(ID, password); //This method must be completed in DBManager class
            
           if (user != null) {
            System.out.println("User is found in the database." + user.getID() + user.getfirstName());
            }
          
           /*
            if (student == null) {                       
            db.addStudent(ID, email, name, password, dob, favcol); //This method must be completed in DBManager class
            System.out.println("Student is added to the database.");
            }
            */
          /*
            if (student != null) {
            db.updateStudent(ID, email, name, password, dob, favcol); // This method must be completed in DBManager class
            System.out.println("Student is updated in the database.");
            }
            */ 
           
            if (user != null) {
            db.deleteUser(ID); // This method must be completed in DBManager class
            System.out.println("User is deleted from the database.");
            }
            
            
            connector.closeConnection(); //Professional practice is to close connection to database once operations are finalized
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
