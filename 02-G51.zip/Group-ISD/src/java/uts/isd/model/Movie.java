package uts.isd.model;

import java.io.Serializable;

/**
 *
 * @author George
 */

public class Movie implements Serializable {

    
    private String ID;   
    private String title;   
    private String genre;    
    private String price;    
    private String copies;    

    public Movie(String ID, String title,String genre,String price,String copies) {
        this.title = title;
        this.genre = genre;
        this.price = price;
        this.copies = copies;
               
        this.ID = ID;
    }

    public Movie() { }
    
    public void updateDetails(String title, String genre, String price, String copies){
        this.title = title;
        this.genre = genre;
        this.price = price;
        this.copies = copies;
      
    }

    public boolean matchID(String ID){
        return this.ID.equals(ID.trim());
    }
    
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCopies() {
        return copies;
    }

    public void setCopies(String copies) {
        this.copies = copies;
    }

   
}//end class
