package uts.isd.model.dao;

import uts.isd.model.Payment;
import java.sql.*;

public class DBManager2 {

    private Statement st;

    public DBManager2(Connection conn) throws SQLException {
        st = conn.createStatement();
    }

   
    public Payment findPayment(String paymentID, String paymentDate) throws SQLException {
        //setup the select sql query string
        String searchQueryString = "select * from PAYMENT where PAYMENTID='" + paymentID + "' AND PAYMENTDATE='" + paymentDate + "'";
        //execute this query using the statement field
       //add the results to a ResultSet
         ResultSet rs = st.executeQuery(searchQueryString);
        //search the ResultSet for a student using the parameters
         boolean hasPayment = rs.next();
         Payment paymentFromDB = null;
                 
         if(hasPayment){
         
             String pID = rs.getString("paymentID");
             String pDate = rs.getString("paymentDate"); 
             
             
             paymentFromDB = new Payment (pID, pDate);
         }
        
         rs.close();
        // st.close();
         
         return paymentFromDB;
         
    }

    //Check if a student exist in the database
    public boolean checkPayment(String paymentID, String paymentDate) throws SQLException {
       //setup the select sql query string
        //execute this query using the statement field
        //add the results to a ResultSet
        //search the ResultSet for a student using the parameters
        //verify if the student exists
        return false;
    }


    public void addPayment(String paymentID, String paymentDate) throws SQLException {        
        //code for add-operation
        
         String createQueryString = "insert into Payment" + " values ('" + paymentID + "', '" + paymentDate + "')";
         boolean recrodCreated = st.executeUpdate(createQueryString) > 0;
         
         if (recrodCreated){
         System.out.println("record created");
         }
         else {
         System.out.println("record not created");
         }
             
    }

    //update a student details in the database
    public void updatePayment(String paymentID, String paymentDate) throws SQLException {
        //code for update-operation
        
       
       
    }
    
    //delete a student from the database
    public void deletePayment(String paymentID) throws SQLException{
        //code for delete-operation
        
        String deleteQueryString = "delete from Payment where ID= '" + paymentID + "' ";
        boolean recrodDeleted = st.executeUpdate(deleteQueryString) > 0;
         
         if (recrodDeleted){
         System.out.println("record deleted");
         }
         else {
         System.out.println("record not deleted");
         }
    }
}
