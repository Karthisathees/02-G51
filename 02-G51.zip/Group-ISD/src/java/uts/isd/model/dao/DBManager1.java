package uts.isd.model.dao;


import java.sql.*;
import uts.isd.model.Movie;

/**
 *
 * @author George
 
 DBManager1 is the primary DAO class to interact with the database and perform CRUD operations with the db.
 Firstly, complete the existing methods and implement them into the application.
 
 So far the application uses the Read and Create operations in the view.
 Secondly, improve the current view to enable the Update and Delete operations.
 */
public class DBManager1 {

    private Statement st;

    public DBManager1(Connection conn) throws SQLException {
        st = conn.createStatement();
    }

    //Find student by ID in the database
    public Movie findMovie(String ID, String title) throws SQLException {
        //setup the select sql query string
        String searchQueryString = "select * from Movie where ID='" + ID + "' AND title='" + title + "'";
        //execute this query using the statement field
       //add the results to a ResultSet
         ResultSet rs = st.executeQuery(searchQueryString);
        //search the ResultSet for a student using the parameters
         boolean hasMovie = rs.next();
         Movie movieFromDB = null;
                 
         if(hasMovie){
         
             String sID = rs.getString("ID");
             String sTitle = rs.getString("title"); 
             String sGenre = rs.getString("genre");
             String sPrice = rs.getString("price");
             String sCopies = rs.getString("copies");
             
             
             movieFromDB = new Movie (sID, sTitle, sGenre, sPrice, sCopies);
         }
        
         rs.close();
        // st.close();
         
         return movieFromDB;
         
    }

    //Check if a student exist in the database
    public boolean checkMovie(String ID, String title) throws SQLException {
       //setup the select sql query string
        //execute this query using the statement field
        //add the results to a ResultSet
        //search the ResultSet for a student using the parameters
        //verify if the student exists
        return false;
    }
    
    public boolean listMovie() throws SQLException {
        String searchQueryString = "select * from Movie";
        ResultSet rs = st.executeQuery(searchQueryString);

        return false;
    }

    //Add a student-data into the database
    public void addMovie(String ID, String title, String genre, String price, String copies) throws SQLException {        
        //code for add-operation
        
         String createQueryString = "insert into Movie" + " values ('" + ID + "', '" + title + "', '" + genre + "', '" + price + "', '" + copies + "')";
         boolean recrodCreated = st.executeUpdate(createQueryString) > 0;
         
         if (recrodCreated){
         System.out.println("record created");
         }
         else {
         System.out.println("record not created");
         }
             
    }

    //update a student details in the database
    public void updateMovie(String ID, String title, String genre, String price, String copies) throws SQLException {
        //code for update-operation
        
        String updateQueryString = "update Movie set title = '" + title + "', genre= '" + genre + "', price = '"  + price + "', copies = '" + copies + "' where ID='" + ID + "'";
        boolean recrodUpdated = st.executeUpdate(updateQueryString) > 0;
         
         if (recrodUpdated){
         System.out.println("record updated");
         }
         else {
         System.out.println("record not updated");
         }
       
    }
    
    //delete a student from the database
    public void deleteMovie(String ID) throws SQLException{
        //code for delete-operation
        
        String deleteQueryString = "delete from Movie where ID= '" + ID + "' ";
        boolean recrodDeleted = st.executeUpdate(deleteQueryString) > 0;
         
         if (recrodDeleted){
         System.out.println("record deleted");
         }
         else {
         System.out.println("record not deleted");
         }
    }
}
