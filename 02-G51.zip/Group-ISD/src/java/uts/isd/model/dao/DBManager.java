package uts.isd.model.dao;

import java.util.Date;
import uts.isd.model.User;
import java.sql.*;

/**
 *
 * @author 
 * 
 * DBManager is the primary DAO class to interact with the database and perform CRUD operations with the db.
 * Firstly, complete the existing methods and implement them into the application.
 * 
 * So far the application uses the Read and Create operations in the view.
 * Secondly, improve the current view to enable the Update and Delete operations.
 */
public class DBManager {

    private Statement st;
    private PreparedStatement pst;
    public DBManager(Connection conn) throws SQLException {
        st = conn.createStatement();
    }

    //Find user by ID in the database
    public User findUser(String ID, String password) throws SQLException {
        //setup the select sql query string
        String searchQueryString = "select * from Customer where ID='" + ID + "' AND password='" + password + "'";
        //execute this query using the statement field
       //add the results to a ResultSet
         ResultSet rs = st.executeQuery(searchQueryString);
        //search the ResultSet for a student using the parameters
         boolean hasUser = rs.next();
         User userFromDB = null;
                 
         if(hasUser){
             String sID = rs.getString("ID"); 
             String sfirstName = rs.getString("firstName"); 
             String slastName = rs.getString("lastName"); 
             String sPassword = rs.getString("password"); 
             String sEmail = rs.getString("email");
             String smobileNumber = rs.getString("mobileNumber");
             userFromDB = new User (sID,sfirstName,slastName, sEmail,sPassword, smobileNumber );
       
             Date date = new Date();
             String query = "insert into userlogs values('"+sID+"','false','"+date.toString()+"')";
             st.execute(query);
    }
                  rs.close();
         
         return userFromDB;
    }
    
    public void logoutLog(String ID) throws SQLException {
        Date date = new Date();
        String query = "insert into userlogs values('"+ID+"','true','"+date.toString()+"')";
        st.execute(query);
    }
    
    public String getLogs(String ID) throws SQLException {
        String sqlQuery = "SELECT * FROM userlogs WHERE userid = '"+ID+"'";
        System.out.println(sqlQuery);
        ResultSet rs = st.executeQuery(sqlQuery);
        String htmlstr = "";
        while(rs.next())
        {
            htmlstr += rs.getString("logtime");
        }
        return htmlstr;
        
    }

    //Check if a user exist in the database
    public boolean checkUser(String ID, String password) throws SQLException {
       //setup the select sql query string
        //String searchQueryString = "select * from Customer where ID='" + ID + "' AND password='" + password + "'";
        //execute this query using the statement field
        //add the results to a ResultSet
        //ResultSet rs = st.executeQuery(searchQueryString);
        //search the ResultSet for a student using the parameters
        //verify if the student exists

        return false;
         
    }

    //Add a user-data into the database
    public void addUser(String ID, String firstName,String lastName, String email, String password, String mobileNumber) throws SQLException {        
        //code for add-operation
        
         String createQueryString = "insert into Customer" + " values ('" + ID + "', '" + firstName + "', '" + lastName + "', '" + email + "', '" + password + "', '" + mobileNumber + "')";
         boolean recrodCreated = st.executeUpdate(createQueryString) > 0;
         
         if (recrodCreated){
         System.out.println("Record created Successfully");
         }
         else {
         System.out.println("Record not created");
         }
    }

    //update a user details in the database
    public void updateUser(String ID,  String firstName,String lastName, String email,String password, String mobileNumber) throws SQLException {
        //code for update-operation
        
        String updateQueryString = "update Customer set firstName = '" + firstName + "', lastName= '" + lastName + "', email = '"  + email + "', password = '" + password + "', mobileNumber = '" + mobileNumber + "' where ID='" + ID + "'";
        boolean recrodUpdated = st.executeUpdate(updateQueryString) > 0;
         
         if (recrodUpdated){
         System.out.println("Record updated Successfully");
         }
         else {
         System.out.println("Record not updated");
         }
    }
    
    //delete a user from the database
    public void deleteUser(String ID) throws SQLException{
        //code for delete-operation
        
        String deleteQueryString = "delete from Customer where ID= '" + ID + "' ";
        boolean recrodDeleted = st.executeUpdate(deleteQueryString) > 0;
         
         if (recrodDeleted){
         System.out.println("Record deleted");
         }
         else {
         System.out.println("Record not deleted");
         }
    }

}
