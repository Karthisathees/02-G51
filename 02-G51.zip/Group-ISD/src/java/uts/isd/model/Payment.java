package uts.isd.model;

import java.io.Serializable;
import java.util.logging.Logger;

/**
 *
 * @author George
 */

public class Payment implements Serializable {

    private String paymentID;
    private String paymentDate;

    public Payment(String paymentID, String paymentDate) {
        this.paymentID = paymentID;
        this.paymentDate = paymentDate;
    }
    public Payment() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getPaymentID() {
        return paymentID;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    
    
    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }
    
    public boolean matchPaymentID(String paymentID){
        return this.paymentID.equals(paymentID.trim());
    }
    
    public boolean matchPaymentDate(String paymentDate){
        return this.paymentDate.equals(paymentDate.trim());
    }
    
    
    
    public void updateDetails(String paymentID, String paymentDate){
        this.paymentID = paymentID;
        this.paymentDate = paymentDate;
    }
    
}//end class
