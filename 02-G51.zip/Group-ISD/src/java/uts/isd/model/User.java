package uts.isd.model;

import java.io.Serializable;


/**
 *
 * @author George
 */

public class User implements Serializable {
    
  
    private String ID;  
    private String firstName; 
    private String lastName;
    private String email;
    private String mobileNumber;
    private String password;    
    

    public User(String ID, String firstName,String lastName, String email,String password,String mobileNumber) {
        this.ID = ID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.password = password;         
    }

    public User() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void updateDetails(String firstName,String lastName, String email,String mobileNumber,String password){
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.password = password;  
    }

    public boolean matchID(String ID){
        return this.ID.equals(ID.trim());
    }
    
    public String getID() {
        return ID;
    }
    
    public void setID(String ID) {
        this.ID = ID;
    }
     
    public boolean matchPassword(String password){
        return this.password.equals(password.trim());
    }

    public String getfirstName() {
        return firstName;
    }
    
    public String getlastName() {
        return lastName;
    }

    public void setfirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public void setlastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getmobileNumber() {
        return mobileNumber;
    }

    public void setmobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public void setemail(String email) {
        this.email= email; //To change body of generated methods, choose Tools | Templates.
    }
}//end class
