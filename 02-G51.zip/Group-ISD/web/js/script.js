function startTime() {
    var date = new Date();
    var n = date.toDateString();
    var time = date.toLocaleTimeString();

    document.getElementById('time').innerHTML = n + ' - ' + time;
    tt = display_c();
}
function display_c() {
    var refresh = 1000;
    mytime = setTimeout('startTime()', refresh);
}

function CheckPassword(password) 
{ 
var passw=  /^[A-Za-z]\w{7,15}$/;
if(password.value.match(passw)) 
{ 
alert('Correct, try another...');
return true;
}
else
{ 
alert('Wrong...!')
return false;
}
}

function pass_validation(password){ 
    if (password==null || password==""){  
  alert("password can't be blank");  
  return false;  
}

    else if(password.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
}  
}  

function mobile_validate(mobileNumber){
 if(mobileNumber==""){
    alert("Please enter the mobile");
    return false;
 }
}
else if(mobileNumber.length < 10){
    alert("Mobile number must have 10 digits");
    return false;
 }
}